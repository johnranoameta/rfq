# Workflow reorder + Supplier Recommendation + Risks & Gaps merge

Implements all three items flagged against the Product Architecture &
Enhancement Recommendations doc.

## 1. Processing tab order

Reordered to match the doc's recommended sequence (its "Requirements" step
doesn't exist as a separate tab yet, so it's omitted rather than invented):

```
Overview → BOM Intelligence → Historical Match → Reuse Opportunities →
Supplier Recommendation → Cost Estimate → Risks & Gaps → Quote History
```

BOM now comes before Matching/Reuse rather than after — matches the actual
data dependency already built in `bomRepository.ts` (you can't intelligently
match or classify reuse until the BOM is normalized and part identities are
resolved).

## 2. Supplier Recommendation (new)

New files:
- `src/lib/rfq/sqlite/supplierRecommendationEngine.ts` — `recommendSupplierForPart(partId)`.
  Ranks known supplier options for a part (approval status first, cost
  second), returns a recommended supplier with rationale, ranked alternates
  with a reason each isn't primary, and a sourcing-risk flag (single-source,
  or recommended-but-unapproved).
- `src/app/api/rfq/suppliers/recommend/route.ts` — `GET ?partId=` for one
  part, or `GET ?bomId=` for every resolved line in a BOM at once (skips
  unmatched lines — nothing to recommend a supplier for without a canonical
  part).

Deliberately a different question from Supplier & Part DB: that panel
browses master data ("what do we know about this part/supplier"); this
answers "who should supply this, and why" for the RFQ open in Processing.
Same underlying `supplier_parts` table, different read.

## 3. Risks & Gaps (merged Coverage + Gap analysis)

New files:
- `src/lib/rfq/sqlite/risksAndGapsAggregator.ts` — `buildRisksAndGaps(rfqId, bomId?)`
  combines `bomCompletenessWarnings()` (BOM-level) with `listRiskFlagsForRfq()`
  (the risk_flags table costing/parts/supplier already write to), sorted by
  severity.
- `src/app/api/rfq/risks-and-gaps/route.ts` — `GET ?rfqId=&bomId=`.

**Scope note, stated plainly:** this merges what the *new* schema tracks. It
does not touch the *existing* gap-analysis system already in the codebase
(`rule_hits`, `rfq_attachments`, `gapFromParsed.ts`,
`reconcileGapsWithDocuments.ts`) — that's a separate, older mechanism with
its own severity model. A real merge needs one query that reconciles both
without double-counting or conflicting severities; that's a follow-up, not
something to fake here. The demo HTML shows the merge conceptually (one
panel, findings + coverage grid together) using the new schema's data only.

## Demo HTML

`public/mockups/09-costing-demo-real-layout.html` updated to match: new tab
order, one merged Risks & Gaps panel (4 findings + the coverage grid,
including a finding that references the Grommet Seal's missing supplier —
ties the merge to Supplier Recommendation rather than reading as two panels
taped together), and a new Supplier Recommendation panel with one card per
BOM line showing the recommended supplier, alternates where they exist, and
risk callouts — mirroring the engine's actual output shape.
